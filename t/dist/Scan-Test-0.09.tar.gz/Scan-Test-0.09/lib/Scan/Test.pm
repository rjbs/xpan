package Scan::Test;

our $VERSION = '0.09';

package Scan::Test::Inner;

our $VERSION = '0.12';

1;
